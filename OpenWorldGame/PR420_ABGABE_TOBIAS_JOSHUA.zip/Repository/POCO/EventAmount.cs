﻿namespace Repository.POCO
{
    public class EventAmount
    {
        public string Name { get; set; }
        public int Amount { get; set; }
    }
}