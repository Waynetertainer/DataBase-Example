﻿using Common.DTO;
using System;
using System.ServiceModel;

namespace OpenWorldGame
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var consumer = new Consumer())
            {

            }
        }
    }
}
