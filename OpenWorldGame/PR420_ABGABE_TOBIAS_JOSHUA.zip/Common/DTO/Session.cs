﻿namespace Common.DTO
{
    public class Session
    {
        public int ID { get; set; }
    }
}
