﻿namespace Common.DTO
{
    public class EventAmount
    {
        public string Name { get; set; }
        public int Amount { get; set; }
    }
}